package com.king.remote;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import android.view.View;

public class MainActivity extends Activity {
    public static String server = "http://127.0.0.1:8080";
    public static String token = "";
    EditText url, key;
    static final int CAPTURE_REQUEST = 44;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(24,24,24,24); box.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this); title.setText("KING DATA CENTER PRO\nКомпаньон Infinix"); title.setTextSize(22);
        url = new EditText(this); url.setSingleLine(); url.setHint("Адрес сервера"); url.setText(server);
        key = new EditText(this); key.setSingleLine(); key.setHint("Токен из Termux");
        Button save = new Button(this); save.setText("Сохранить подключение");
        Button start = new Button(this); start.setText("Начать трансляцию экрана");
        Button stop = new Button(this); stop.setText("Остановить трансляцию");
        Button access = new Button(this); access.setText("Настроить удалённые нажатия");
        TextView note = new TextView(this);
        note.setText("Трансляция начнётся только после системного подтверждения Android. Для нажатий вручную включите службу KING в специальных возможностях. Используйте только в своей Wi-Fi сети.");
        box.addView(title); box.addView(url); box.addView(key); box.addView(save); box.addView(start); box.addView(stop); box.addView(access); box.addView(note);
        setContentView(box);
        save.setOnClickListener(v -> { server=url.getText().toString().trim(); token=key.getText().toString().trim(); Toast.makeText(this,"Настройки сохранены",Toast.LENGTH_SHORT).show(); });
        start.setOnClickListener(v -> { save.performClick(); if(token.isEmpty()){Toast.makeText(this,"Введи токен",Toast.LENGTH_LONG).show();return;}
            MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE); startActivityForResult(m.createScreenCaptureIntent(),CAPTURE_REQUEST); });
        stop.setOnClickListener(v -> stopService(new Intent(this,CaptureService.class)));
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
    }
    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if(req==CAPTURE_REQUEST && res==RESULT_OK && data!=null) {
            Intent i=new Intent(this,CaptureService.class); i.putExtra("result",res); i.putExtra("data",data);
            i.putExtra("server",server); i.putExtra("token",token);
            if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        } else if(req==CAPTURE_REQUEST) Toast.makeText(this,"Разрешение на трансляцию не выдано",Toast.LENGTH_LONG).show();
    }
}